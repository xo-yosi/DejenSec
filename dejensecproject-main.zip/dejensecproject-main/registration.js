let currentPage = 1;
const formPages = document.querySelectorAll('.form-page');

function showPage(pageNumber) {
  formPages.forEach(page => {
    page.style.display = 'none';
  });
  formPages[pageNumber - 1].style.display = 'block';
}

function nextPage() {
  if (currentPage < formPages.length) {
    currentPage++;
    showPage(currentPage);
  } else {
    form.reset(); 
  }
}

function previousPage() {
  if (currentPage > 1) {
    currentPage--;
    showPage(currentPage);
  }
}

showPage(currentPage);