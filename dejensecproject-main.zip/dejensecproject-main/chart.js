
  var ctx = document.getElementById('myChart').getContext('2d');

  // Define the chart data
  var data = {
    labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    datasets: [{
      label: 'My Dataset',
      data: [12, 19, 3, 5, 2, 3],
      backgroundColor: 'rgba(255, 99, 132, 0.5)'
    }]
  };

  // Define the chart options
  var options = {
    responsive: true,
    maintainAspectRatio: false
  };

  // Create and render the chart
  var myChart = new Chart(ctx, {
    type: 'bar',
    data: data,
    options: options
  });



