document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: 'dayGridMonth',
      events: [
      {
        title: 'Coding Session',
        start: '2023-05-25',
        end: '2023-05-27',
        color: 'blueviolet'
      },
      {
        title: 'BASH',
        start: '2023-05-21',
        end: '2023-05-23',
        color: 'red'
      },
      {
        title: 'Web App pentesting',
        start: '2023-05-01',
        end: '2023-05-03',
        color: 'red'
      },
      {
        title: 'Cryptography',
        start: '2023-05-05',
        end: '2023-05-08',
        color: 'green',
      },
      {
        title: 'SQL Injection',
        start: '2023-05-10',
        end: '2023-05-13',
        color: 'black'
      },
      {
        title: 'Video Conference',
        start: '2023-05-28',
        end: '2023-05-28',
        color: 'blue'
      },
      {
        title: 'Command Injection',
        start: '2023-05-30',
        end: '2023-06-01',
        color: 'purple'
      }

    ]
    });
    calendar.render();
  });