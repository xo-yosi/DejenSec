window.addEventListener("scroll", function() {
    var navbar = document.getElementById("navbar");
    var scroll = window.pageYOffset || document.documentElement.scrollTop;
  
    if (scroll > 0) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  });  